package guru.springframework.sfgpetclinic.model;

public class Owner extends Person {
}
