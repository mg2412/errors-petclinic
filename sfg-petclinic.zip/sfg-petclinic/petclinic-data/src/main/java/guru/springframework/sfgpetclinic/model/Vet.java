package guru.springframework.sfgpetclinic.model;

public class Vet extends Person
{
}
