package guru.springframeworl.sfgpetclinic;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SfgPetclinicApplicationTests {

    @Test
    public void contextLoads() {
    }

}

